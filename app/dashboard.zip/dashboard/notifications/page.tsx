import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bell, CheckCircle, Clock, DollarSign, LineChart, MessageSquare, Settings, User } from "lucide-react"

const notifications = [
  {
    id: 1,
    title: "Profit Target Reached",
    description: "You've reached 80% of your profit target for Phase 1.",
    time: "2 hours ago",
    category: "account",
    isRead: false,
    icon: LineChart,
  },
  {
    id: 2,
    title: "New Trading Challenge",
    description: "Join our weekly trading challenge to win extra bonuses.",
    time: "Yesterday",
    category: "promotion",
    isRead: false,
    icon: DollarSign,
  },
  {
    id: 3,
    title: "Account Metrics Updated",
    description: "Your account metrics have been updated for the previous week.",
    time: "3 days ago",
    category: "account",
    isRead: true,
    icon: User,
  },
  {
    id: 4,
    title: "Upcoming Payout",
    description: "Your next payout is scheduled for April 15, 2023.",
    time: "5 days ago",
    category: "payout",
    isRead: true,
    icon: DollarSign,
  },
  {
    id: 5,
    title: "New Message from Support",
    description: "Your support ticket #1234 has been updated with a new response.",
    time: "1 week ago",
    category: "support",
    isRead: true,
    icon: MessageSquare,
  },
  {
    id: 6,
    title: "Trading Rules Updated",
    description: "We've updated our trading rules. Please review the changes.",
    time: "2 weeks ago",
    category: "system",
    isRead: true,
    icon: Settings,
  },
  {
    id: 7,
    title: "Maintenance Scheduled",
    description: "System maintenance scheduled for April 20, 2023, from 2 AM to 4 AM EST.",
    time: "2 weeks ago",
    category: "system",
    isRead: true,
    icon: Settings,
  },
  {
    id: 8,
    title: "New Educational Content",
    description: "We've added new courses to the Trading Academy. Check them out!",
    time: "3 weeks ago",
    category: "promotion",
    isRead: true,
    icon: Bell,
  },
]

export default function NotificationsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Notifications" description="Stay updated with important alerts and information." />

      <div className="flex items-center justify-between">
        <Tabs defaultValue="all" className="w-full">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="unread">Unread</TabsTrigger>
              <TabsTrigger value="account">Account</TabsTrigger>
              <TabsTrigger value="system">System</TabsTrigger>
            </TabsList>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="h-8">
                <CheckCircle className="mr-2 h-4 w-4" />
                Mark All as Read
              </Button>
              <Button variant="outline" size="sm" className="h-8">
                <Settings className="mr-2 h-4 w-4" />
                Notification Settings
              </Button>
            </div>
          </div>

          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>All Notifications</CardTitle>
                <CardDescription>View all your notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`flex items-start gap-4 rounded-lg border p-4 ${
                        !notification.isRead ? "bg-amber-50 border-amber-200" : ""
                      }`}
                    >
                      <div
                        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                          !notification.isRead ? "bg-[#EB9D2E]/20 text-[#EB9D2E]" : "bg-zinc-100 text-zinc-500"
                        }`}
                      >
                        <notification.icon className="h-5 w-5" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">{notification.title}</h3>
                          <div className="flex items-center gap-2">
                            <Badge
                              variant="outline"
                              className={
                                notification.category === "account"
                                  ? "border-blue-200 text-blue-700"
                                  : notification.category === "payout"
                                    ? "border-emerald-200 text-emerald-700"
                                    : notification.category === "system"
                                      ? "border-purple-200 text-purple-700"
                                      : notification.category === "support"
                                        ? "border-orange-200 text-orange-700"
                                        : "border-zinc-200 text-zinc-700"
                              }
                            >
                              {notification.category}
                            </Badge>
                            {!notification.isRead && <Badge className="bg-[#EB9D2E] text-black">New</Badge>}
                          </div>
                        </div>
                        <p className="text-sm text-zinc-600">{notification.description}</p>
                        <div className="flex items-center justify-between text-xs text-zinc-500">
                          <div className="flex items-center">
                            <Clock className="mr-1 h-3 w-3" />
                            {notification.time}
                          </div>
                          {!notification.isRead && (
                            <Button variant="link" size="sm" className="h-auto p-0 text-[#EB9D2E]">
                              Mark as read
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="unread">
            <Card>
              <CardHeader>
                <CardTitle>Unread Notifications</CardTitle>
                <CardDescription>View your unread notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notifications
                    .filter((notification) => !notification.isRead)
                    .map((notification) => (
                      <div
                        key={notification.id}
                        className="flex items-start gap-4 rounded-lg border p-4 bg-amber-50 border-amber-200"
                      >
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#EB9D2E]/20 text-[#EB9D2E]">
                          <notification.icon className="h-5 w-5" />
                        </div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium">{notification.title}</h3>
                            <div className="flex items-center gap-2">
                              <Badge
                                variant="outline"
                                className={
                                  notification.category === "account"
                                    ? "border-blue-200 text-blue-700"
                                    : notification.category === "payout"
                                      ? "border-emerald-200 text-emerald-700"
                                      : notification.category === "system"
                                        ? "border-purple-200 text-purple-700"
                                        : notification.category === "support"
                                          ? "border-orange-200 text-orange-700"
                                          : "border-zinc-200 text-zinc-700"
                                }
                              >
                                {notification.category}
                              </Badge>
                              <Badge className="bg-[#EB9D2E] text-black">New</Badge>
                            </div>
                          </div>
                          <p className="text-sm text-zinc-600">{notification.description}</p>
                          <div className="flex items-center justify-between text-xs text-zinc-500">
                            <div className="flex items-center">
                              <Clock className="mr-1 h-3 w-3" />
                              {notification.time}
                            </div>
                            <Button variant="link" size="sm" className="h-auto p-0 text-[#EB9D2E]">
                              Mark as read
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>Account Notifications</CardTitle>
                <CardDescription>View notifications related to your account</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notifications
                    .filter((notification) => notification.category === "account")
                    .map((notification) => (
                      <div
                        key={notification.id}
                        className={`flex items-start gap-4 rounded-lg border p-4 ${
                          !notification.isRead ? "bg-amber-50 border-amber-200" : ""
                        }`}
                      >
                        <div
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                            !notification.isRead ? "bg-[#EB9D2E]/20 text-[#EB9D2E]" : "bg-zinc-100 text-zinc-500"
                          }`}
                        >
                          <notification.icon className="h-5 w-5" />
                        </div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium">{notification.title}</h3>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="border-blue-200 text-blue-700">
                                {notification.category}
                              </Badge>
                              {!notification.isRead && <Badge className="bg-[#EB9D2E] text-black">New</Badge>}
                            </div>
                          </div>
                          <p className="text-sm text-zinc-600">{notification.description}</p>
                          <div className="flex items-center justify-between text-xs text-zinc-500">
                            <div className="flex items-center">
                              <Clock className="mr-1 h-3 w-3" />
                              {notification.time}
                            </div>
                            {!notification.isRead && (
                              <Button variant="link" size="sm" className="h-auto p-0 text-[#EB9D2E]">
                                Mark as read
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system">
            <Card>
              <CardHeader>
                <CardTitle>System Notifications</CardTitle>
                <CardDescription>View system-related notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notifications
                    .filter((notification) => notification.category === "system")
                    .map((notification) => (
                      <div
                        key={notification.id}
                        className={`flex items-start gap-4 rounded-lg border p-4 ${
                          !notification.isRead ? "bg-amber-50 border-amber-200" : ""
                        }`}
                      >
                        <div
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                            !notification.isRead ? "bg-[#EB9D2E]/20 text-[#EB9D2E]" : "bg-zinc-100 text-zinc-500"
                          }`}
                        >
                          <notification.icon className="h-5 w-5" />
                        </div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium">{notification.title}</h3>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="border-purple-200 text-purple-700">
                                {notification.category}
                              </Badge>
                              {!notification.isRead && <Badge className="bg-[#EB9D2E] text-black">New</Badge>}
                            </div>
                          </div>
                          <p className="text-sm text-zinc-600">{notification.description}</p>
                          <div className="flex items-center justify-between text-xs text-zinc-500">
                            <div className="flex items-center">
                              <Clock className="mr-1 h-3 w-3" />
                              {notification.time}
                            </div>
                            {!notification.isRead && (
                              <Button variant="link" size="sm" className="h-auto p-0 text-[#EB9D2E]">
                                Mark as read
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
