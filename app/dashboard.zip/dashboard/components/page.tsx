"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PreviewButton } from "@/components/preview-button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart2, LineChart, PieChart } from "lucide-react"

export default function ComponentsPage() {
  // Example state for editing a card component
  const [cardTitle, setCardTitle] = useState("Account Balance")
  const [cardValue, setCardValue] = useState("$16,543.00")
  const [cardDescription, setCardDescription] = useState("↑ 12.5% from last month")
  const [showBadge, setShowBadge] = useState(true)
  const [badgeText, setBadgeText] = useState("80%")

  // Example state for editing a chart component
  const [chartTitle, setChartTitle] = useState("Daily Performance")
  const [chartDescription, setChartDescription] = useState("Your profit and loss for the past week")
  const [chartType, setChartType] = useState("bar")

  // Example card component to preview
  const cardComponent = (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{cardTitle}</CardTitle>
        <PieChart className="h-4 w-4 text-zinc-500" />
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2">
          <div className="text-2xl font-bold text-zinc-900 dark:text-zinc-50">{cardValue}</div>
          {showBadge && <Badge className="bg-[#EB9D2E] text-black">{badgeText}</Badge>}
        </div>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">{cardDescription}</p>
      </CardContent>
    </Card>
  )

  // Example chart component to preview
  const chartComponent = (
    <Card>
      <CardHeader>
        <CardTitle>{chartTitle}</CardTitle>
        <CardDescription>{chartDescription}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          <div className="flex h-full w-full items-center justify-center">
            <div className="text-center">
              <div className="mb-4 flex justify-center">
                {chartType === "bar" ? (
                  <BarChart2 className="h-12 w-12 text-zinc-300" />
                ) : chartType === "line" ? (
                  <LineChart className="h-12 w-12 text-zinc-300" />
                ) : (
                  <PieChart className="h-12 w-12 text-zinc-300" />
                )}
              </div>
              <p className="text-sm text-zinc-500 dark:text-zinc-400">Chart visualization</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )

  // Example card edit form
  const cardEditForm = (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="card-title">Card Title</Label>
        <Input id="card-title" value={cardTitle} onChange={(e) => setCardTitle(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="card-value">Card Value</Label>
        <Input id="card-value" value={cardValue} onChange={(e) => setCardValue(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="card-description">Description</Label>
        <Input id="card-description" value={cardDescription} onChange={(e) => setCardDescription(e.target.value)} />
      </div>
      <div className="flex items-center justify-between">
        <Label htmlFor="show-badge">Show Badge</Label>
        <Switch id="show-badge" checked={showBadge} onCheckedChange={setShowBadge} />
      </div>
      {showBadge && (
        <div className="space-y-2">
          <Label htmlFor="badge-text">Badge Text</Label>
          <Input id="badge-text" value={badgeText} onChange={(e) => setBadgeText(e.target.value)} />
        </div>
      )}
    </div>
  )

  // Example chart edit form
  const chartEditForm = (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="chart-title">Chart Title</Label>
        <Input id="chart-title" value={chartTitle} onChange={(e) => setChartTitle(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="chart-description">Chart Description</Label>
        <Input id="chart-description" value={chartDescription} onChange={(e) => setChartDescription(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="chart-type">Chart Type</Label>
        <Select value={chartType} onValueChange={setChartType}>
          <SelectTrigger id="chart-type">
            <SelectValue placeholder="Select chart type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="bar">Bar Chart</SelectItem>
            <SelectItem value="line">Line Chart</SelectItem>
            <SelectItem value="pie">Pie Chart</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  )

  // Example code for the card component
  const cardCode = `<Card>
  <CardHeader className="flex flex-row items-center justify-between pb-2">
    <CardTitle className="text-sm font-medium">${cardTitle}</CardTitle>
    <PieChart className="h-4 w-4 text-zinc-500" />
  </CardHeader>
  <CardContent>
    <div className="flex items-center gap-2">
      <div className="text-2xl font-bold text-zinc-900 dark:text-zinc-50">${cardValue}</div>
      ${showBadge ? `<Badge className="bg-[#EB9D2E] text-black">${badgeText}</Badge>` : ""}
    </div>
    <p className="text-xs text-zinc-500 dark:text-zinc-400">${cardDescription}</p>
  </CardContent>
</Card>`

  // Example code for the chart component
  const chartCode = `<Card>
  <CardHeader>
    <CardTitle>${chartTitle}</CardTitle>
    <CardDescription>${chartDescription}</CardDescription>
  </CardHeader>
  <CardContent>
    <div className="h-[300px] w-full">
      <div className="flex h-full w-full items-center justify-center">
        <div className="text-center">
          <div className="mb-4 flex justify-center">
            ${
              chartType === "bar"
                ? '<BarChart2 className="h-12 w-12 text-zinc-300" />'
                : chartType === "line"
                  ? '<LineChart className="h-12 w-12 text-zinc-300" />'
                  : '<PieChart className="h-12 w-12 text-zinc-300" />'
            }
          </div>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">Chart visualization</p>
        </div>
      </div>
    </div>
  </CardContent>
</Card>`

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Component Library" description="Preview, edit, and customize dashboard components." />

      <Tabs defaultValue="cards">
        <TabsList className="mb-4">
          <TabsTrigger value="cards">Cards</TabsTrigger>
          <TabsTrigger value="charts">Charts</TabsTrigger>
          <TabsTrigger value="tables">Tables</TabsTrigger>
          <TabsTrigger value="forms">Forms</TabsTrigger>
        </TabsList>

        <TabsContent value="cards">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Account Balance Card</CardTitle>
                <CardDescription>Display account balance with trend indicator</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-md border p-4 dark:border-zinc-800">{cardComponent}</div>
                <div className="flex justify-end">
                  <PreviewButton
                    title="Account Balance Card"
                    description="Preview and customize this component"
                    component={cardComponent}
                    code={cardCode}
                    editForm={cardEditForm}
                    onSave={() => console.log("Saved card component")}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Chart Component</CardTitle>
                <CardDescription>Visualize data with customizable charts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-md border p-4 dark:border-zinc-800">
                  <div className="scale-[0.85] transform">{chartComponent}</div>
                </div>
                <div className="flex justify-end">
                  <PreviewButton
                    title="Chart Component"
                    description="Preview and customize this chart"
                    component={chartComponent}
                    code={chartCode}
                    editForm={chartEditForm}
                    onSave={() => console.log("Saved chart component")}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Add more component previews here */}
          </div>
        </TabsContent>

        <TabsContent value="charts">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Chart components would go here */}
            <Card>
              <CardHeader>
                <CardTitle>Coming Soon</CardTitle>
                <CardDescription>Chart components will be available soon</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex h-[200px] items-center justify-center">
                  <p className="text-zinc-500 dark:text-zinc-400">Chart components are under development</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tables">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Table components would go here */}
            <Card>
              <CardHeader>
                <CardTitle>Coming Soon</CardTitle>
                <CardDescription>Table components will be available soon</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex h-[200px] items-center justify-center">
                  <p className="text-zinc-500 dark:text-zinc-400">Table components are under development</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="forms">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Form components would go here */}
            <Card>
              <CardHeader>
                <CardTitle>Coming Soon</CardTitle>
                <CardDescription>Form components will be available soon</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex h-[200px] items-center justify-center">
                  <p className="text-zinc-500 dark:text-zinc-400">Form components are under development</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
