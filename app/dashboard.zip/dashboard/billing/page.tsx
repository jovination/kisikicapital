import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CreditCard, Download, Plus, Receipt, Shield, Star } from "lucide-react"

const subscriptionDetails = {
  plan: "One Phase Challenge",
  status: "Active",
  nextBilling: "May 15, 2023",
  amount: "$250.00",
  accountSize: "$25,000",
}

const paymentMethods = [
  {
    id: "pm-1",
    type: "Visa",
    last4: "4242",
    expiry: "04/25",
    isDefault: true,
  },
  {
    id: "pm-2",
    type: "Mastercard",
    last4: "5555",
    expiry: "08/24",
    isDefault: false,
  },
]

const invoices = [
  {
    id: "INV-001",
    date: "Apr 15, 2023",
    amount: "$250.00",
    status: "Paid",
    description: "One Phase Challenge - Monthly Subscription",
  },
  {
    id: "INV-002",
    date: "Mar 15, 2023",
    amount: "$250.00",
    status: "Paid",
    description: "One Phase Challenge - Monthly Subscription",
  },
  {
    id: "INV-003",
    date: "Feb 15, 2023",
    amount: "$250.00",
    status: "Paid",
    description: "One Phase Challenge - Monthly Subscription",
  },
]

const availablePlans = [
  {
    name: "One Phase Challenge",
    price: "$250",
    accountSize: "$25,000",
    features: ["80% Profit Split", "5% Max Drawdown", "10% Profit Target", "Unlimited Time"],
    popular: false,
  },
  {
    name: "Two Phase Challenge",
    price: "$350",
    accountSize: "$50,000",
    features: ["80% Profit Split", "8% Max Drawdown", "8% Profit Target (Each Phase)", "30 Days Per Phase"],
    popular: true,
  },
  {
    name: "Instant Funding",
    price: "$550",
    accountSize: "$25,000",
    features: ["70% Profit Split", "10% Max Drawdown", "No Profit Target", "Immediate Live Account"],
    popular: false,
  },
]

export default function BillingPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Billing" description="Manage your subscription, payment methods, and billing history." />

      <Tabs defaultValue="subscription">
        <TabsList className="mb-4">
          <TabsTrigger value="subscription">Subscription</TabsTrigger>
          <TabsTrigger value="payment-methods">Payment Methods</TabsTrigger>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
          <TabsTrigger value="plans">Available Plans</TabsTrigger>
        </TabsList>

        <TabsContent value="subscription">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Current Subscription</CardTitle>
                <CardDescription>Details about your current trading plan</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Plan</span>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{subscriptionDetails.plan}</span>
                      <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300">
                        {subscriptionDetails.status}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Account Size</span>
                    <span className="font-medium">{subscriptionDetails.accountSize}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Next Billing</span>
                    <span className="font-medium">{subscriptionDetails.nextBilling}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Amount</span>
                    <span className="font-medium">{subscriptionDetails.amount}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between border-t px-6 py-4">
                <Button variant="outline">Cancel Subscription</Button>
                <Button className="bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90 dark:text-black">Change Plan</Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Subscription Benefits</CardTitle>
                <CardDescription>Features included in your current plan</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900 dark:text-emerald-300">
                      <Shield className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <p className="font-medium">80% Profit Split</p>
                      <p className="text-sm text-zinc-500 dark:text-zinc-400">
                        Keep 80% of all profits you generate on your account
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900 dark:text-emerald-300">
                      <Shield className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <p className="font-medium">5% Maximum Drawdown</p>
                      <p className="text-sm text-zinc-500 dark:text-zinc-400">
                        Your account will remain active as long as you stay within the 5% drawdown limit
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900 dark:text-emerald-300">
                      <Shield className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <p className="font-medium">10% Profit Target</p>
                      <p className="text-sm text-zinc-500 dark:text-zinc-400">
                        Reach a 10% profit target to qualify for payouts
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900 dark:text-emerald-300">
                      <Shield className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <p className="font-medium">Unlimited Time</p>
                      <p className="text-sm text-zinc-500 dark:text-zinc-400">
                        No time limit to reach your profit target
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t px-6 py-4">
                <Button variant="outline" className="w-full">
                  View Full Trading Rules
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="payment-methods">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Payment Methods</CardTitle>
                  <CardDescription>Manage your saved payment methods</CardDescription>
                </div>
                <Button className="bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90 dark:text-black">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Payment Method
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className="flex items-center justify-between rounded-lg border p-4 dark:border-zinc-800"
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-md bg-zinc-100 dark:bg-zinc-800">
                        <CreditCard className="h-5 w-5 text-zinc-600 dark:text-zinc-400" />
                      </div>
                      <div>
                        <p className="font-medium">
                          {method.type} •••• {method.last4}
                        </p>
                        <p className="text-sm text-zinc-500 dark:text-zinc-400">Expires {method.expiry}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {method.isDefault && (
                        <Badge variant="outline" className="border-zinc-200 dark:border-zinc-700">
                          Default
                        </Badge>
                      )}
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                      {!method.isDefault && (
                        <Button variant="outline" size="sm">
                          Remove
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="invoices">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Billing History</CardTitle>
                  <CardDescription>View and download your invoices</CardDescription>
                </div>
                <Button variant="outline">
                  <Receipt className="mr-2 h-4 w-4" />
                  Export All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {invoices.map((invoice) => (
                  <div
                    key={invoice.id}
                    className="flex items-center justify-between rounded-lg border p-4 dark:border-zinc-800"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{invoice.id}</p>
                        <Badge
                          className={
                            invoice.status === "Paid"
                              ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300"
                              : "bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300"
                          }
                        >
                          {invoice.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-zinc-500 dark:text-zinc-400">{invoice.description}</p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">{invoice.date}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-medium">{invoice.amount}</span>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        PDF
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="plans">
          <div className="grid gap-6 md:grid-cols-3">
            {availablePlans.map((plan) => (
              <Card key={plan.name} className={plan.popular ? "border-[#EB9D2E] dark:border-[#EB9D2E]" : ""}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-[#EB9D2E] px-3 py-1 text-xs font-medium text-black">
                    Most Popular
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{plan.name}</span>
                    {plan.popular && <Star className="h-5 w-5 text-[#EB9D2E]" />}
                  </CardTitle>
                  <CardDescription>
                    <div className="mt-2 flex items-baseline">
                      <span className="text-3xl font-bold">{plan.price}</span>
                      <span className="ml-1 text-sm text-zinc-500 dark:text-zinc-400">/month</span>
                    </div>
                    <p className="mt-1 text-sm">Account Size: {plan.accountSize}</p>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <div className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900 dark:text-emerald-300">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-3 w-3"
                          >
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                        </div>
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button
                    className={
                      plan.popular ? "w-full bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90 dark:text-black" : "w-full"
                    }
                  >
                    {subscriptionDetails.plan === plan.name ? "Current Plan" : "Select Plan"}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
