import { AccountInformation } from "@/components/dashboard/account-information"
import { AccountOverview } from "@/components/dashboard/account-overview"
import { PageHeader } from "@/components/dashboard/page-header"
import { PerformanceCharts } from "@/components/dashboard/performance-charts"
import { RecentTrades } from "@/components/dashboard/recent-trades"
import { UpcomingPayouts } from "@/components/dashboard/upcoming-payouts"

export default function DashboardPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Dashboard" description="Welcome back, John Doe. Here's an overview of your trading account." />
      <AccountOverview />
      <PerformanceCharts />
      <div className="grid gap-6 md:grid-cols-3">
        <RecentTrades />
        <UpcomingPayouts />
      </div>
      <AccountInformation />
    </div>
  )
}
