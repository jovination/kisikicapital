import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PerformanceCharts } from "@/components/dashboard/performance-charts"
import { BarChart2, LineChart, PieChart } from "lucide-react"

export default function AnalyticsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Analytics" description="Detailed analysis of your trading performance and metrics." />

      <Tabs defaultValue="performance">
        <TabsList className="mb-4">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="instruments">Instruments</TabsTrigger>
          <TabsTrigger value="timeframes">Timeframes</TabsTrigger>
        </TabsList>

        <TabsContent value="performance">
          <PerformanceCharts />

          <div className="grid gap-6 mt-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Risk-Reward Ratio</CardTitle>
                <CardDescription>Average across all trades</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex h-[200px] items-center justify-center flex-col">
                  <PieChart className="h-12 w-12 text-zinc-300 mb-4" />
                  <div className="text-3xl font-bold text-zinc-900">1:2.5</div>
                  <p className="text-sm text-zinc-500">Excellent risk management</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Sharpe Ratio</CardTitle>
                <CardDescription>Risk-adjusted return</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex h-[200px] items-center justify-center flex-col">
                  <LineChart className="h-12 w-12 text-zinc-300 mb-4" />
                  <div className="text-3xl font-bold text-zinc-900">1.8</div>
                  <p className="text-sm text-zinc-500">Above average performance</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Profit Factor</CardTitle>
                <CardDescription>Gross profit / Gross loss</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex h-[200px] items-center justify-center flex-col">
                  <BarChart2 className="h-12 w-12 text-zinc-300 mb-4" />
                  <div className="text-3xl font-bold text-zinc-900">2.3</div>
                  <p className="text-sm text-zinc-500">Strong profitability</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="instruments">
          <Card>
            <CardHeader>
              <CardTitle>Instrument Performance</CardTitle>
              <CardDescription>Performance breakdown by trading instrument</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] w-full">
                <div className="flex h-full w-full items-center justify-center">
                  <div className="text-center">
                    <div className="mb-4 flex justify-center">
                      <BarChart2 className="h-12 w-12 text-zinc-300" />
                    </div>
                    <p className="text-sm text-zinc-500">Instrument performance visualization</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timeframes">
          <Card>
            <CardHeader>
              <CardTitle>Timeframe Analysis</CardTitle>
              <CardDescription>Performance across different trading timeframes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] w-full">
                <div className="flex h-full w-full items-center justify-center">
                  <div className="text-center">
                    <div className="mb-4 flex justify-center">
                      <LineChart className="h-12 w-12 text-zinc-300" />
                    </div>
                    <p className="text-sm text-zinc-500">Timeframe analysis visualization</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
