import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UpcomingPayouts } from "@/components/dashboard/upcoming-payouts"
import Link from "next/link"

const payoutHistory = [
  {
    id: "PO-3419",
    amount: 1850,
    status: "Completed",
    date: "Mar 15, 2023",
    method: "Bank Transfer",
  },
  {
    id: "PO-3418",
    amount: 1200,
    status: "Completed",
    date: "Feb 15, 2023",
    method: "Bank Transfer",
  },
  {
    id: "PO-3417",
    amount: 950,
    status: "Completed",
    date: "Jan 15, 2023",
    method: "PayPal",
  },
]

export default function PayoutsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Payouts" description="Manage your payouts and view your payment history." />

      <Tabs defaultValue="upcoming">
        <TabsList className="mb-4">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming">
          <div className="grid gap-6 md:grid-cols-2">
            <UpcomingPayouts />

            <Card>
              <CardHeader>
                <CardTitle>Payout Eligibility</CardTitle>
                <CardDescription>Your current payout status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Profit Target</span>
                    <Badge className="bg-emerald-100 text-emerald-700">Achieved</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Trading Days</span>
                    <Badge className="bg-emerald-100 text-emerald-700">Completed</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Max Drawdown</span>
                    <Badge className="bg-emerald-100 text-emerald-700">Within Limits</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Overall Status</span>
                    <Badge className="bg-[#EB9D2E] text-black">Eligible</Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/dashboard/payouts/request" className="w-full">
                  <Button className="w-full bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90">Request Payout</Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Payout History</CardTitle>
              <CardDescription>Your previous payouts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {payoutHistory.map((payout) => (
                  <div key={payout.id} className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-zinc-900">{payout.id}</span>
                        <Badge className="bg-emerald-100 text-emerald-700">{payout.status}</Badge>
                      </div>
                      <div className="text-xs text-zinc-500">{payout.date}</div>
                      <div className="text-xs text-zinc-500">Method: {payout.method}</div>
                    </div>
                    <div className="text-xl font-bold text-zinc-900">${payout.amount.toFixed(2)}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Payout Settings</CardTitle>
              <CardDescription>Configure your payout preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Payout Method</h3>
                  <div className="flex items-center gap-2 rounded-lg border p-4">
                    <div className="flex-1">
                      <p className="font-medium">Bank Transfer (Primary)</p>
                      <p className="text-sm text-zinc-500">Account ending in ****6789</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Edit
                    </Button>
                  </div>
                  <div className="flex items-center gap-2 rounded-lg border p-4">
                    <div className="flex-1">
                      <p className="font-medium">PayPal</p>
                      <p className="text-sm text-zinc-500">john.doe@example.com</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Edit
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Payout Schedule</h3>
                  <div className="flex items-center gap-2 rounded-lg border p-4">
                    <div className="flex-1">
                      <p className="font-medium">Monthly</p>
                      <p className="text-sm text-zinc-500">Payouts processed on the 15th of each month</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Change
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
