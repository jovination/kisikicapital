import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function PayoutRequestPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Request Payout" description="Submit a request to withdraw your profits." />

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Payout Request Form</CardTitle>
              <CardDescription>Fill in the details to request your payout</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="amount">Payout Amount</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-zinc-500">$</span>
                    <Input id="amount" type="number" placeholder="0.00" className="pl-7" />
                  </div>
                  <p className="text-xs text-zinc-500">Available balance: $1,250.00</p>
                </div>

                <div className="space-y-2">
                  <Label>Payout Method</Label>
                  <RadioGroup defaultValue="bank" className="space-y-3">
                    <div className="flex items-start space-x-3 rounded-md border p-3">
                      <RadioGroupItem value="bank" id="bank" className="mt-1" />
                      <div className="space-y-1.5 leading-none">
                        <Label htmlFor="bank" className="font-medium">
                          Bank Transfer (Primary)
                        </Label>
                        <p className="text-sm text-zinc-500">Account ending in ****6789</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3 rounded-md border p-3">
                      <RadioGroupItem value="paypal" id="paypal" className="mt-1" />
                      <div className="space-y-1.5 leading-none">
                        <Label htmlFor="paypal" className="font-medium">
                          PayPal
                        </Label>
                        <p className="text-sm text-zinc-500">john.doe@example.com</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3 rounded-md border p-3">
                      <RadioGroupItem value="crypto" id="crypto" className="mt-1" />
                      <div className="space-y-1.5 leading-none">
                        <Label htmlFor="crypto" className="font-medium">
                          Cryptocurrency
                        </Label>
                        <p className="text-sm text-zinc-500">Add a new cryptocurrency wallet</p>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notes (Optional)</Label>
                  <Textarea id="notes" placeholder="Any additional information about your payout request" />
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox id="terms" />
                  <div className="space-y-1 leading-none">
                    <Label htmlFor="terms" className="text-sm font-medium">
                      I confirm that I have met all trading requirements and am eligible for a payout
                    </Label>
                    <p className="text-xs text-zinc-500">
                      By submitting this request, you confirm that you have adhered to all trading rules and conditions.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t px-6 py-4">
              <Button variant="outline">Cancel</Button>
              <Button className="bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90">Submit Request</Button>
            </CardFooter>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Payout Information</CardTitle>
              <CardDescription>Important details about your payout</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Available Balance</h3>
                  <p className="text-2xl font-bold text-zinc-900">$1,250.00</p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Processing Time</h3>
                  <p className="text-sm text-zinc-600">
                    Payouts are typically processed within 1-3 business days, depending on your chosen payment method.
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Fees</h3>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Bank Transfer:</span>
                      <span>$15.00</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>PayPal:</span>
                      <span>3% of amount</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Cryptocurrency:</span>
                      <span>$5.00 + network fee</span>
                    </div>
                  </div>
                </div>

                <Alert variant="warning" className="bg-amber-50 text-amber-800 border-amber-200">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Important</AlertTitle>
                  <AlertDescription>
                    Minimum payout amount is $100. Ensure your account details are correct before submitting.
                  </AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Payout Schedule</CardTitle>
              <CardDescription>When to expect your funds</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Next Payout Date</h3>
                  <p className="text-zinc-900">April 15, 2023</p>
                  <p className="text-xs text-zinc-500">Requests must be submitted by April 12, 2023</p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Payout Frequency</h3>
                  <p className="text-zinc-900">Monthly (15th of each month)</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
