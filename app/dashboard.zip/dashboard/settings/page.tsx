"use client"

import { useTheme } from "next-themes"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ThemeToggle } from "@/components/theme-toggle"

export default function SettingsPage() {
  const { theme, setTheme } = useTheme()

  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Settings" description="Configure your account settings and preferences." />

      <Tabs defaultValue="general">
        <TabsList className="mb-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="trading">Trading</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="api">API Access</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Manage your general account settings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="timezone">Timezone</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">
                      Set your preferred timezone for all dates and times
                    </p>
                  </div>
                  <Select defaultValue="America/New_York">
                    <SelectTrigger className="w-[240px]">
                      <SelectValue placeholder="Select timezone" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="America/New_York">Eastern Time (ET)</SelectItem>
                      <SelectItem value="America/Chicago">Central Time (CT)</SelectItem>
                      <SelectItem value="America/Denver">Mountain Time (MT)</SelectItem>
                      <SelectItem value="America/Los_Angeles">Pacific Time (PT)</SelectItem>
                      <SelectItem value="Europe/London">London (GMT)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Language</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">
                      Set your preferred language for the dashboard
                    </p>
                  </div>
                  <Select defaultValue="en">
                    <SelectTrigger className="w-[240px]">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Spanish</SelectItem>
                      <SelectItem value="fr">French</SelectItem>
                      <SelectItem value="de">German</SelectItem>
                      <SelectItem value="zh">Chinese</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notifications">Email Notifications</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Receive important updates via email</p>
                  </div>
                  <Switch id="email-notifications" defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="marketing-emails">Marketing Emails</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Receive promotional offers and news</p>
                  </div>
                  <Switch id="marketing-emails" />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90 dark:text-black">Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="trading">
          <Card>
            <CardHeader>
              <CardTitle>Trading Settings</CardTitle>
              <CardDescription>Configure your trading preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Default Trading Platform</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Set your preferred trading platform</p>
                  </div>
                  <Select defaultValue="mt5">
                    <SelectTrigger className="w-[240px]">
                      <SelectValue placeholder="Select platform" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mt5">MetaTrader 5</SelectItem>
                      <SelectItem value="mt4">MetaTrader 4</SelectItem>
                      <SelectItem value="ctrader">cTrader</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Risk Management</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Set maximum risk per trade</p>
                  </div>
                  <Select defaultValue="2">
                    <SelectTrigger className="w-[240px]">
                      <SelectValue placeholder="Select risk percentage" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1% of account</SelectItem>
                      <SelectItem value="2">2% of account</SelectItem>
                      <SelectItem value="3">3% of account</SelectItem>
                      <SelectItem value="5">5% of account</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="trade-confirmations">Trade Confirmations</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">
                      Require confirmation before placing trades
                    </p>
                  </div>
                  <Switch id="trade-confirmations" defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="trade-notifications">Trade Notifications</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">
                      Receive notifications for trade executions
                    </p>
                  </div>
                  <Switch id="trade-notifications" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90 dark:text-black">Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Appearance Settings</CardTitle>
              <CardDescription>Customize how the dashboard looks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="dark-mode">Dark Mode</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Switch between light and dark themes</p>
                  </div>
                  <ThemeToggle variant="switch" />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Chart Color Theme</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Set your preferred chart colors</p>
                  </div>
                  <Select defaultValue="default">
                    <SelectTrigger className="w-[240px]">
                      <SelectValue placeholder="Select theme" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="default">Default</SelectItem>
                      <SelectItem value="monochrome">Monochrome</SelectItem>
                      <SelectItem value="colorful">Colorful</SelectItem>
                      <SelectItem value="trading">Trading View</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Dashboard Layout</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Choose your preferred dashboard layout</p>
                  </div>
                  <Select defaultValue="default">
                    <SelectTrigger className="w-[240px]">
                      <SelectValue placeholder="Select layout" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="default">Default</SelectItem>
                      <SelectItem value="compact">Compact</SelectItem>
                      <SelectItem value="expanded">Expanded</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90 dark:text-black">Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle>API Access</CardTitle>
              <CardDescription>Manage API keys for third-party integrations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="font-medium">API Key</p>
                      <p className="text-sm text-zinc-500 dark:text-zinc-400">
                        Use this key to access your account via API
                      </p>
                    </div>
                    <Button variant="outline">Generate New Key</Button>
                  </div>
                  <div className="bg-zinc-100 dark:bg-zinc-800 p-3 rounded-md font-mono text-sm">
                    ••••••••••••••••••••••••••••••••
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="api-access">API Access</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">
                      Enable or disable API access to your account
                    </p>
                  </div>
                  <Switch id="api-access" defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="webhook-notifications">Webhook Notifications</Label>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Send trade events to external services</p>
                  </div>
                  <Switch id="webhook-notifications" />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90 dark:text-black">Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
