import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const supportTickets = [
  {
    id: "TKT-1234",
    subject: "Account Verification Issue",
    status: "Open",
    priority: "High",
    date: "Apr 8, 2023",
    lastUpdate: "2 hours ago",
  },
  {
    id: "TKT-1233",
    subject: "Trading Platform Connection Problem",
    status: "In Progress",
    priority: "Medium",
    date: "Apr 5, 2023",
    lastUpdate: "Yesterday",
  },
  {
    id: "TKT-1232",
    subject: "Payout Request Clarification",
    status: "Closed",
    priority: "Low",
    date: "Mar 28, 2023",
    lastUpdate: "Mar 30, 2023",
  },
]

const faqs = [
  {
    question: "How do I pass the prop firm challenge?",
    answer:
      "To pass the prop firm challenge, you need to achieve the profit target while staying within the maximum drawdown limits. Focus on consistent trading with proper risk management rather than trying to hit the profit target quickly.",
  },
  {
    question: "When do I receive my payouts?",
    answer:
      "Payouts are processed on the 15th of each month for all eligible traders. You must have met your profit targets and adhered to all trading rules to qualify for a payout.",
  },
  {
    question: "What happens if I exceed the maximum drawdown?",
    answer:
      "If you exceed the maximum drawdown limit, your account will be automatically closed. This applies to both daily and overall maximum drawdown limits as specified in your account terms.",
  },
  {
    question: "Can I trade on weekends?",
    answer:
      "Most forex markets are closed on weekends. However, you can trade cryptocurrencies which operate 24/7. Please note that weekend trading may have different liquidity conditions.",
  },
  {
    question: "How do I reset my password?",
    answer:
      "To reset your password, go to the login page and click on 'Forgot Password'. Follow the instructions sent to your registered email address to create a new password.",
  },
]

export default function SupportPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Support" description="Get help with your account and trading questions." />

      <Tabs defaultValue="tickets">
        <TabsList className="mb-4">
          <TabsTrigger value="tickets">My Tickets</TabsTrigger>
          <TabsTrigger value="new">New Ticket</TabsTrigger>
          <TabsTrigger value="faq">FAQ</TabsTrigger>
          <TabsTrigger value="contact">Contact</TabsTrigger>
        </TabsList>

        <TabsContent value="tickets">
          <Card>
            <CardHeader>
              <CardTitle>Support Tickets</CardTitle>
              <CardDescription>View and manage your support requests</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {supportTickets.map((ticket) => (
                  <div key={ticket.id} className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{ticket.subject}</h3>
                        <Badge
                          className={
                            ticket.status === "Open"
                              ? "bg-blue-100 text-blue-700"
                              : ticket.status === "In Progress"
                                ? "bg-[#EB9D2E] text-black"
                                : "bg-zinc-100 text-zinc-700"
                          }
                        >
                          {ticket.status}
                        </Badge>
                        <Badge
                          className={
                            ticket.priority === "High"
                              ? "bg-rose-100 text-rose-700"
                              : ticket.priority === "Medium"
                                ? "bg-amber-100 text-amber-700"
                                : "bg-emerald-100 text-emerald-700"
                          }
                        >
                          {ticket.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-zinc-500">Ticket ID: {ticket.id}</p>
                      <p className="text-sm text-zinc-500">
                        Created: {ticket.date} • Last update: {ticket.lastUpdate}
                      </p>
                    </div>
                    <Button
                      variant={ticket.status === "Closed" ? "outline" : "default"}
                      className={ticket.status !== "Closed" ? "bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90" : ""}
                    >
                      View Ticket
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="new">
          <Card>
            <CardHeader>
              <CardTitle>Create New Support Ticket</CardTitle>
              <CardDescription>Submit a new support request</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Input id="subject" placeholder="Brief description of your issue" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select>
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="account">Account</SelectItem>
                        <SelectItem value="trading">Trading</SelectItem>
                        <SelectItem value="platform">Platform</SelectItem>
                        <SelectItem value="payout">Payout</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority</Label>
                    <Select>
                      <SelectTrigger id="priority">
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Please provide details about your issue"
                    className="min-h-[150px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="attachment">Attachments (optional)</Label>
                  <Input id="attachment" type="file" />
                  <p className="text-xs text-zinc-500">You can upload screenshots or relevant files (max 5MB)</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90">Submit Ticket</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="faq">
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
              <CardDescription>Find answers to common questions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {faqs.map((faq, index) => (
                  <div key={index} className="rounded-lg border p-4">
                    <h3 className="font-medium mb-2">{faq.question}</h3>
                    <p className="text-sm text-zinc-600">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <p className="text-sm text-zinc-500">
                Can't find what you're looking for?{" "}
                <Button variant="link" className="p-0 h-auto text-[#EB9D2E]">
                  Create a support ticket
                </Button>
              </p>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="contact">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
                <CardDescription>Ways to reach our support team</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-1">Email Support</h3>
                    <p className="text-sm text-zinc-500 mb-3">support@kisikicapital.com</p>
                    <p className="text-sm text-zinc-500">Response time: Within 24 hours</p>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-1">Live Chat</h3>
                    <p className="text-sm text-zinc-500 mb-3">Available Monday-Friday, 9AM-5PM EST</p>
                    <Button className="w-full bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90">Start Chat</Button>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-1">Phone Support</h3>
                    <p className="text-sm text-zinc-500 mb-3">+1 (555) 123-4567</p>
                    <p className="text-sm text-zinc-500">Available for Premium accounts only</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Send Us a Message</CardTitle>
                <CardDescription>Quick contact form for general inquiries</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input id="name" placeholder="Your name" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="Your email address" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea id="message" placeholder="How can we help you?" className="min-h-[120px]" />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90">Send Message</Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
