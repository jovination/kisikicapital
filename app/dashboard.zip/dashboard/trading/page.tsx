import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RecentTrades } from "@/components/dashboard/recent-trades"
import { BarChart2, LineChart, PieChart } from "lucide-react"

export default function TradingPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Trading" description="Manage your trading activities and view your performance." />

      <Tabs defaultValue="active">
        <TabsList className="mb-4">
          <TabsTrigger value="active">Active Trades</TabsTrigger>
          <TabsTrigger value="history">Trade History</TabsTrigger>
          <TabsTrigger value="stats">Statistics</TabsTrigger>
        </TabsList>

        <TabsContent value="active">
          <Card>
            <CardHeader>
              <CardTitle>Active Trades</CardTitle>
              <CardDescription>Your currently open positions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex h-[200px] items-center justify-center">
                <p className="text-zinc-500">No active trades at the moment</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <RecentTrades />
        </TabsContent>

        <TabsContent value="stats">
          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Win Rate</CardTitle>
                <CardDescription>Your trading success rate</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex h-[200px] items-center justify-center flex-col">
                  <PieChart className="h-12 w-12 text-zinc-300 mb-4" />
                  <div className="text-3xl font-bold text-zinc-900">68%</div>
                  <p className="text-sm text-zinc-500">Based on last 100 trades</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average Profit</CardTitle>
                <CardDescription>Per winning trade</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex h-[200px] items-center justify-center flex-col">
                  <LineChart className="h-12 w-12 text-zinc-300 mb-4" />
                  <div className="text-3xl font-bold text-zinc-900">$245.32</div>
                  <p className="text-sm text-zinc-500">+12% from last month</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average Loss</CardTitle>
                <CardDescription>Per losing trade</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex h-[200px] items-center justify-center flex-col">
                  <BarChart2 className="h-12 w-12 text-zinc-300 mb-4" />
                  <div className="text-3xl font-bold text-zinc-900">$98.75</div>
                  <p className="text-sm text-zinc-500">-5% from last month</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
