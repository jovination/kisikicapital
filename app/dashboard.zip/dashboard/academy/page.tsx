import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { PageHeader } from "@/components/dashboard/page-header"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"

const courses = [
  {
    id: "course-1",
    title: "Forex Trading Fundamentals",
    description: "Learn the basics of forex trading and market analysis",
    level: "Beginner",
    duration: "4 hours",
    progress: 100,
    completed: true,
  },
  {
    id: "course-2",
    title: "Technical Analysis Mastery",
    description: "Master chart patterns and technical indicators",
    level: "Intermediate",
    duration: "6 hours",
    progress: 65,
    completed: false,
  },
  {
    id: "course-3",
    title: "Risk Management Strategies",
    description: "Learn how to protect your capital and manage risk",
    level: "Intermediate",
    duration: "3 hours",
    progress: 30,
    completed: false,
  },
  {
    id: "course-4",
    title: "Advanced Trading Psychology",
    description: "Understand the psychological aspects of trading",
    level: "Advanced",
    duration: "5 hours",
    progress: 0,
    completed: false,
  },
]

const webinars = [
  {
    id: "webinar-1",
    title: "Market Outlook for Q2 2023",
    date: "Apr 15, 2023",
    time: "2:00 PM EST",
    host: "Sarah Johnson",
    status: "Upcoming",
  },
  {
    id: "webinar-2",
    title: "Trading the News: Strategies and Tactics",
    date: "Apr 22, 2023",
    time: "1:00 PM EST",
    host: "Michael Chen",
    status: "Upcoming",
  },
  {
    id: "webinar-3",
    title: "Prop Firm Challenge Success Strategies",
    date: "Mar 30, 2023",
    time: "3:00 PM EST",
    host: "David Williams",
    status: "Recorded",
  },
]

export default function AcademyPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader title="Trading Academy" description="Enhance your trading skills with our educational resources." />

      <Tabs defaultValue="courses">
        <TabsList className="mb-4">
          <TabsTrigger value="courses">Courses</TabsTrigger>
          <TabsTrigger value="webinars">Webinars</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
        </TabsList>

        <TabsContent value="courses">
          <div className="grid gap-6 md:grid-cols-2">
            {courses.map((course) => (
              <Card key={course.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{course.title}</CardTitle>
                    <Badge
                      className={
                        course.level === "Beginner"
                          ? "bg-emerald-100 text-emerald-700"
                          : course.level === "Intermediate"
                            ? "bg-blue-100 text-blue-700"
                            : "bg-purple-100 text-purple-700"
                      }
                    >
                      {course.level}
                    </Badge>
                  </div>
                  <CardDescription>{course.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between text-sm">
                      <span>Duration: {course.duration}</span>
                      <span>Progress: {course.progress}%</span>
                    </div>
                    <Progress value={course.progress} className="h-2" />
                  </div>
                </CardContent>
                <CardFooter>
                  <Link href={`/dashboard/academy/courses/${course.id}`} className="w-full">
                    <Button
                      className={`w-full ${course.completed ? "bg-emerald-600 hover:bg-emerald-700" : "bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90"}`}
                    >
                      {course.completed ? "Review Course" : course.progress > 0 ? "Continue Course" : "Start Course"}
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="webinars">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming & Recorded Webinars</CardTitle>
              <CardDescription>Join live sessions with trading experts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {webinars.map((webinar) => (
                  <div key={webinar.id} className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{webinar.title}</h3>
                        <Badge
                          className={
                            webinar.status === "Upcoming" ? "bg-[#EB9D2E] text-black" : "bg-zinc-100 text-zinc-700"
                          }
                        >
                          {webinar.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-zinc-500">Host: {webinar.host}</p>
                      <p className="text-sm text-zinc-500">
                        {webinar.date} at {webinar.time}
                      </p>
                    </div>
                    <Button
                      variant={webinar.status === "Upcoming" ? "default" : "outline"}
                      className={webinar.status === "Upcoming" ? "bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90" : ""}
                    >
                      {webinar.status === "Upcoming" ? "Register" : "Watch Recording"}
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Trading Guides</CardTitle>
                <CardDescription>Comprehensive guides on various trading topics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-1">Prop Firm Trading Guide</h3>
                    <p className="text-sm text-zinc-500 mb-3">Complete guide to passing prop firm challenges</p>
                    <Button variant="outline" className="w-full">
                      Download PDF
                    </Button>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-1">Risk Management Handbook</h3>
                    <p className="text-sm text-zinc-500 mb-3">Essential risk management strategies for traders</p>
                    <Button variant="outline" className="w-full">
                      Download PDF
                    </Button>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-1">Technical Analysis Cheat Sheet</h3>
                    <p className="text-sm text-zinc-500 mb-3">Quick reference for chart patterns and indicators</p>
                    <Button variant="outline" className="w-full">
                      Download PDF
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Trading Tools</CardTitle>
                <CardDescription>Useful tools to enhance your trading</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-1">Position Size Calculator</h3>
                    <p className="text-sm text-zinc-500 mb-3">Calculate optimal position sizes based on risk</p>
                    <Button className="w-full bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90">Open Tool</Button>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-1">Economic Calendar</h3>
                    <p className="text-sm text-zinc-500 mb-3">Stay updated with important economic events</p>
                    <Button className="w-full bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90">Open Tool</Button>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h3 className="font-medium mb-1">Trading Journal Template</h3>
                    <p className="text-sm text-zinc-500 mb-3">Track and analyze your trading performance</p>
                    <Button className="w-full bg-[#EB9D2E] text-black hover:bg-[#EB9D2E]/90">Open Tool</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
